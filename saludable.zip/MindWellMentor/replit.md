# MentalCare Companion

## Descripción del Proyecto
MentalCare Companion es una aplicación web de apoyo a la salud mental que permite a los usuarios:
- Registrar su estado emocional diario
- Acceder a una biblioteca de recursos de bienestar (meditaciones, ejercicios de respiración, artículos)
- Mantener un diario personal privado
- Visualizar su progreso y estadísticas de bienestar

## Arquitectura Técnica

### Frontend
- **Framework**: React con TypeScript
- **Routing**: Wouter
- **Estilos**: Tailwind CSS + Shadcn UI
- **Estado**: TanStack Query para gestión de datos del servidor
- **Tema**: Sistema de temas claro/oscuro con ThemeProvider

### Backend
- **Framework**: Express.js
- **Base de datos**: PostgreSQL (Neon)
- **ORM**: Drizzle ORM
- **Validación**: Zod

### Estructura de Datos

#### Tablas Principales
1. **users** - Información del usuario y preferencias
2. **mood_entries** - Registros de estado emocional
3. **journal_entries** - Entradas del diario personal
4. **resources** - Biblioteca de recursos de bienestar
5. **completed_resources** - Seguimiento de recursos completados
6. **goals** - Metas y objetivos de bienestar personal

## Características Principales

### 1. Dashboard
- Bienvenida personalizada con fecha actual
- Resumen del estado de ánimo actual
- Gráfico de tendencia de últimos 7 días
- Estadísticas: racha de registros, entradas de diario, recursos completados
- Accesos rápidos a todas las funciones

### 2. Registro de Estado de Ánimo
- Selector visual de 5 emociones: Feliz, Tranquilo, Ansioso, Triste, Neutral
- Cada emoción con color e icono distintivo
- Campo de notas opcional para contexto adicional
- Guardado automático con redirección al dashboard

### 3. Biblioteca de Recursos
- 4 categorías: Meditación, Respiración, Artículos, Ejercicios
- **Filtros avanzados**: búsqueda por texto, categorías múltiples, rango de duración
- Marcado de recursos como completados
- Barra de progreso global
- 6 recursos iniciales pre-cargados

### 4. Diario Personal
- Editor de texto libre para reflexiones
- Vista cronológica de entradas anteriores
- Timestamps completos con formato en español
- Estados vacíos amigables

### 5. Tendencias Emocionales
- **Análisis de patrones**: distribución de emociones con gráficos de barras
- **Tendencias semanales**: evolución del estado de ánimo últimos 7 días
- **Insights personalizados**: sugerencias basadas en datos positivos/negativos
- **Estadísticas**: emoción más frecuente, días registrados, promedio semanal

### 6. Metas y Objetivos
- **Creación de metas**: título, descripción opcional, fecha objetivo opcional
- **Seguimiento de progreso**: estado activo/completado, fecha de finalización
- **Estadísticas**: metas activas, completadas, tasa de éxito
- **Celebración de logros**: ícono de trofeo, badge "Completada", distinción visual

### 7. Configuración
- Actualización de nombre de usuario
- Toggle de tema oscuro/claro (persiste en localStorage)
- **Exportación de datos**: mood/journal en JSON y CSV con fecha
- Resumen de actividad del usuario
- Sección de datos y privacidad

## Diseño Visual

### Paleta de Colores
- **Primary**: Azul suave (confianza y calma)
- **Success**: Verde calmante
- **Accent Warm**: Coral suave (ánimo)
- **Mood Colors**: 
  - Feliz: Amarillo dorado
  - Tranquilo: Azul suave
  - Ansioso: Púrpura suave
  - Triste: Azul grisáceo
  - Neutral: Gris suave

### Principios de Diseño
- Interfaz cálida y empática
- Espaciado consistente (sistema de 4, 6, 8, 12, 16, 24)
- Tipografía clara (Inter como fuente principal)
- Animaciones sutiles y suaves
- Estados de carga con skeletons
- Mensajes de error amigables

## API Endpoints

### Usuario
- `GET /api/user` - Obtener usuario actual
- `PATCH /api/user` - Actualizar preferencias

### Estado de Ánimo
- `GET /api/mood-entries` - Obtener registros de ánimo
- `POST /api/mood-entries` - Crear nuevo registro

### Diario
- `GET /api/journal-entries` - Obtener entradas del diario
- `POST /api/journal-entries` - Crear nueva entrada

### Recursos
- `GET /api/resources` - Obtener todos los recursos
- `POST /api/resources` - Crear nuevo recurso (admin)

### Recursos Completados
- `GET /api/completed-resources` - Obtener recursos completados
- `POST /api/completed-resources` - Marcar recurso como completado
- `DELETE /api/completed-resources/:id` - Desmarcar recurso

### Metas
- `GET /api/goals` - Obtener todas las metas del usuario
- `POST /api/goals` - Crear nueva meta
- `PATCH /api/goals/:id` - Actualizar meta (completar/desmarcar)
- `DELETE /api/goals/:id` - Eliminar meta

## Estado Actual
- ✅ Schema completo definido con 6 tablas
- ✅ Base de datos PostgreSQL configurada
- ✅ Todos los componentes frontend implementados
- ✅ Todos los endpoints backend implementados
- ✅ Sistema de temas claro/oscuro implementado
- ✅ Navegación con sidebar
- ✅ Datos de recursos pre-cargados
- ✅ Filtros avanzados en recursos (búsqueda, categorías, duración)
- ✅ Análisis de tendencias emocionales
- ✅ Exportación de datos (JSON/CSV)
- ✅ Sistema de metas y objetivos

## Características Completadas
- **MVP Core**: Dashboard, registro de ánimo, recursos, diario, configuración
- **Filtros Avanzados**: Búsqueda por texto, filtrado por categorías, rango de duración
- **Exportación de Datos**: JSON y CSV para mood/journal entries
- **Análisis de Tendencias**: Gráficos de distribución, tendencias semanales, insights personalizados
- **Sistema de Metas**: Creación, seguimiento, celebración de logros, estadísticas de éxito

## Próximos Pasos Potenciales
- Sistema de notificaciones/recordatorios push
- Integración con calendario para metas
- Reportes mensuales de bienestar
- Comunidad y grupos de apoyo
- Conexión con profesionales de la salud mental
